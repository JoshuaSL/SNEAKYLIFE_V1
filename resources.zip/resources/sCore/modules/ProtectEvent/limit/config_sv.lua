ConfigEventProtect = {}

ConfigEventProtect.RateLimit = 100
ConfigEventProtect.ResetRateLimit = 5000
ConfigEventProtect.KickMessage = "Allez moins vite !"